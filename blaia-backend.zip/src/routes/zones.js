const express = require('express');
const router = express.Router();

// Aquí irá la lógica para crear y listar zonas

router.get('/', (req, res) => {
  res.json([{ name: 'Capellades', postalCode: '08786' }]);
});

module.exports = router;

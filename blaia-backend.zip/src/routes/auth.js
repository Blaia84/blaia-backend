const express = require('express');
const router = express.Router();

// Aquí irá el código para registro, login, verificación SMS/email

router.post('/register', (req, res) => {
  res.send('Registro simulado');
});

module.exports = router;

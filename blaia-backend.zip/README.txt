# Blaia Backend MVP - Fase 1

## ¿Qué contiene este proyecto?

- Registro básico de usuarios
- Rutas de ejemplo para autenticación y zonas
- Preparado para subir a Render
- .env.example con las variables necesarias

## ¿Qué debes hacer tú?

1. Crea una cuenta en https://render.com
2. Sube este proyecto como un nuevo "Web Service"
3. Añade las variables de entorno usando el archivo .env.example como referencia
4. Usa PostgreSQL (Render te permite crear una base de datos desde el panel)
5. Cuando esté desplegado, Render te dará una URL como:
   https://blaia-backend.onrender.com

## ¿Qué viene después?

- Conectaremos este backend al frontend React
- Activaremos las funciones reales de registro, envío de SMS y validación de email
